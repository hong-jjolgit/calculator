from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    total_length = 0
    total_weight = 0
    purchase_quantity = 0
    total_cutting_cost = 0
    width = height = thickness = 0
    type_of_pipe = ""
    sizes = ["" for _ in range(10)]
    quantities = ["" for _ in range(10)]

    if request.method == 'POST':
        type_of_pipe = request.form.get('type', '')
        width = float(request.form.get('width', 0) or 0)
        height = float(request.form.get('height', 0) or 0)
        thickness = float(request.form.get('thickness', 0) or 0)

        for i in range(1, 11):
            size = request.form.get(f'size{i}', '')
            quantity = request.form.get(f'quantity{i}', '')
            if size and quantity:
                size = float(size) if size else 0
                quantity = int(quantity) if quantity else 0
                sizes[i-1] = size
                quantities[i-1] = quantity
                if size > 0 and quantity > 0:
                    length = size * quantity
                    weight = -(3.287 * thickness - (width + height)) * thickness * 0.0157 * length / 1000
                    total_length += length
                    total_weight += weight
                    purchase_quantity += length / 1000
                    if size < 1000:
                        total_cutting_cost += quantity

    total_weight = round(total_weight, 2)
    return render_template('index.html', total_length=total_length, total_weight=total_weight, purchase_quantity=purchase_quantity, total_cutting_cost=total_cutting_cost,
                           type_of_pipe=type_of_pipe, width=width, height=height, thickness=thickness, sizes=sizes, quantities=quantities)

if __name__ == '__main__':
    app.run(debug=True)